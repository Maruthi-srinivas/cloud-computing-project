﻿import requests

BASE_URL = "http://localhost:5000"

def add_node(cpu_cores):
    response = requests.post(f"{BASE_URL}/add_node", json={"cpu_cores": cpu_cores})
    print("Add Node:", response.json())

def launch_pod(cpu_requirement):
    response = requests.post(f"{BASE_URL}/launch_pod", json={"cpu_requirement": cpu_requirement})
    print("Launch Pod:", response.json())

def list_nodes():
    response = requests.get(f"{BASE_URL}/nodes")
    print("Nodes:", response.json())

def send_heartbeat(node_id):
    response = requests.post(f"{BASE_URL}/heartbeat", json={"node_id": node_id})
    print("Heartbeat:", response.json())

if __name__ == "__main__":
    # Example usage:
    add_node(4)              # Adds a node with 4 CPU cores and launches a Docker container.
    launch_pod(2)            # Launches a pod that requires 2 CPU cores.
    list_nodes()             # Lists all nodes and their statuses.
    # To manually send a heartbeat, replace '<node_id>' with an actual node ID:
    # send_heartbeat("<node_id>")

