﻿from flask import Flask, request, jsonify
from node_manager import NodeManager
from pod_scheduler import PodScheduler
from health_monitor import HealthMonitor

app = Flask(__name__)

# Initialize the managers.
node_manager = NodeManager()
pod_scheduler = PodScheduler(node_manager)

# Start the background health monitor thread.
health_monitor = HealthMonitor(node_manager, pod_scheduler)
health_monitor.start()

@app.route("/add_node", methods=["POST"])
def add_node():
    """
    Endpoint to add a new node.
    Expects JSON with "cpu_cores" (an integer > 0).
    This process follows the node addition process flow:
    1. User provides CPU cores.
    2. A Docker container is launched to simulate the node.
    3. Node is registered and resources allocated.
    4. Heartbeat initialization begins.
    """
    data = request.get_json()
    cpu_cores = data.get("cpu_cores")
    if cpu_cores is None or not isinstance(cpu_cores, int) or cpu_cores <= 0:
        return jsonify({"error": "Invalid CPU cores specification"}), 400
    node = node_manager.add_node(cpu_cores)
    return jsonify({
        "message": "Node added",
        "node_id": node.id,
        "container_id": node.container_id
    }), 200

@app.route("/launch_pod", methods=["POST"])
def launch_pod():
    """
    Endpoint to launch a new pod.
    Expects JSON with "cpu_requirement" (an integer > 0).
    Follows the pod launch process flow:
    1. Client request is received.
    2. API server validates available resources.
    3. Pod Scheduler selects a node and reserves resources.
    4. Pod is deployed and stored.
    5. Client is notified.
    """
    data = request.get_json()
    cpu_req = data.get("cpu_requirement")
    if cpu_req is None or not isinstance(cpu_req, int) or cpu_req <= 0:
        return jsonify({"error": "Invalid CPU requirement"}), 400
    pod = pod_scheduler.add_pod(cpu_req)
    if pod is None:
        return jsonify({"error": "No available node to schedule the pod"}), 400
    return jsonify({
        "message": "Pod launched",
        "pod_id": pod.id,
        "assigned_node": pod.assigned_node
    }), 200

@app.route("/nodes", methods=["GET"])
def list_nodes():
    """
    Endpoint to list all nodes in the cluster along with their details.
    Provides node ID, CPU resources, hosted pods, last heartbeat, status, and Docker container ID.
    """
    node_list = [node.to_dict() for node in node_manager.get_nodes().values()]
    return jsonify({"nodes": node_list}), 200

@app.route("/heartbeat", methods=["POST"])
def heartbeat():
    """
    Endpoint for nodes to send a heartbeat.
    Expects JSON with "node_id". Updates the node's last heartbeat and status.
    """
    data = request.get_json()
    node_id = data.get("node_id")
    if node_id not in node_manager.nodes:
        return jsonify({"error": "Node not found"}), 404
    node_manager.update_heartbeat(node_id)
    return jsonify({"message": "Heartbeat received", "node_id": node_id}), 200

if __name__ == "__main__":
    # Run the Flask API server on port 5000.
    app.run(host="0.0.0.0", port=5000)

