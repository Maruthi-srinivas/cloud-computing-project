﻿from models import Pod

class PodScheduler:
    def __init__(self, node_manager):
        self.node_manager = node_manager
        self.pods = {}  # Dictionary mapping pod_id to Pod objects

    def schedule_pod(self, pod):
        # 1. Node Selection: Iterate over healthy nodes.
        for node in self.node_manager.nodes.values():
            if node.status == "healthy" and node.cpu_available >= pod.cpu_requirement:
                # 2. Resource Reservation & Pod Deployment:
                node.pods.append(pod.id)
                node.cpu_available -= pod.cpu_requirement
                pod.assigned_node = node.id
                return True
        return False

    def add_pod(self, cpu_requirement):
        # Create a new pod and attempt to schedule it.
        pod = Pod(cpu_requirement)
        scheduled = self.schedule_pod(pod)
        if scheduled:
            self.pods[pod.id] = pod
            print(f"[Pod Scheduler] Pod {pod.id} requiring {cpu_requirement} CPU cores launched on node {pod.assigned_node}.")
            return pod
        else:
            return None

    def get_pods(self):
        return self.pods

