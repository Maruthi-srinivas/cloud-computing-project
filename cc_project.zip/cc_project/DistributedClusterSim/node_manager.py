﻿
from models import Node
import time
import docker

class NodeManager:
    def __init__(self):
        self.nodes = {}  # Dictionary mapping node_id to Node objects
        self.docker_client = docker.from_env()

    def add_node(self, cpu_cores):
        # 1. Resource Specification & Node Registration:
        node = Node(cpu_cores)
        self.nodes[node.id] = node
        print(f"[Node Manager] Node {node.id} added with {cpu_cores} CPU cores.")

        # 2. Container Launch: Launch a Docker container to simulate the physical node.
        #    The container will run the node_container.py script and send periodic heartbeats.
        try:
            container = self.docker_client.containers.run(
                "node_simulator:latest",    # Ensure you build this image using the Dockerfile below.
                detach=True,
                environment={
                    "NODE_ID": node.id,
                    # Adjust the API_SERVER_URL if necessary (host.docker.internal works for Docker Desktop).
                    "API_SERVER_URL": "http://host.docker.internal:5000"
                },
                name=f"node_{node.id}",
                restart_policy={"Name": "always"}
            )
            node.container_id = container.id
            print(f"[Node Manager] Docker container launched for node {node.id} (container id: {node.container_id}).")
        except Exception as e:
            print(f"[Node Manager] Error launching Docker container for node {node.id}: {e}")

        return node

    def get_nodes(self):
        return self.nodes

    def update_heartbeat(self, node_id):
        # Update the heartbeat time for the node, and if it was failed, mark it healthy.
        if node_id in self.nodes:
            node = self.nodes[node_id]
            node.last_heartbeat = time.time()
            if node.status == "failed":
                node.status = "healthy"
                print(f"[Heartbeat] Node {node_id} is back online.")
            else:
                print(f"[Heartbeat] Received heartbeat from node {node_id}.")
            return node
        return None
