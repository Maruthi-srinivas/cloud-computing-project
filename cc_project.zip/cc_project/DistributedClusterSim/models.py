﻿import time
import uuid

class Node:
    def __init__(self, cpu_total):
        self.id = str(uuid.uuid4())                  # Unique node identifier
        self.cpu_total = cpu_total                   # Total CPU cores specified at addition
        self.cpu_available = cpu_total               # Available CPU cores (will decrease as pods are added)
        self.pods = []                               # List of pod IDs hosted on this node
        self.last_heartbeat = time.time()            # Time of last heartbeat received
        self.status = "healthy"                      # "healthy" or "failed"
        self.container_id = None                     # Docker container id for the simulated node

    def to_dict(self):
        return {
            "id": self.id,
            "cpu_total": self.cpu_total,
            "cpu_available": self.cpu_available,
            "pods": self.pods,
            "last_heartbeat": self.last_heartbeat,
            "status": self.status,
            "container_id": self.container_id
        }

class Pod:
    def __init__(self, cpu_requirement):
        self.id = str(uuid.uuid4())                  # Unique pod identifier
        self.cpu_requirement = cpu_requirement       # CPU cores required for this pod
        self.assigned_node = None                    # The node to which the pod is scheduled

    def to_dict(self):
        return {
            "id": self.id,
            "cpu_requirement": self.cpu_requirement,
            "assigned_node": self.assigned_node
        }

