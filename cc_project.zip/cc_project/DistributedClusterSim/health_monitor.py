﻿import time
import threading

# HEARTBEAT_THRESHOLD is the maximum allowed time (in seconds) between heartbeats.
HEARTBEAT_THRESHOLD = 10

class HealthMonitor(threading.Thread):
    def __init__(self, node_manager, pod_scheduler):
        super().__init__(daemon=True)
        self.node_manager = node_manager
        self.pod_scheduler = pod_scheduler

    def run(self):
        while True:
            now = time.time()
            # Check each node's heartbeat.
            for node in list(self.node_manager.nodes.values()):
                if node.status == "healthy" and now - node.last_heartbeat > HEARTBEAT_THRESHOLD:
                    print(f"[Health Monitor] Node {node.id} missed heartbeat, marking as failed.")
                    node.status = "failed"
                    # 1. Save pods running on the failed node for rescheduling.
                    failed_pods = node.pods.copy()
                    node.pods = []
                    node.cpu_available = node.cpu_total  # Reset resources.
                    # 2. Recovery Actions: Attempt to reschedule pods.
                    for pod_id in failed_pods:
                        pod = self.pod_scheduler.pods.get(pod_id)
                        if pod:
                            pod.assigned_node = None
                            if self.pod_scheduler.schedule_pod(pod):
                                print(f"[Health Monitor] Pod {pod.id} rescheduled to node {pod.assigned_node}.")
                            else:
                                print(f"[Health Monitor] Pod {pod.id} could not be rescheduled!")
            time.sleep(5)

