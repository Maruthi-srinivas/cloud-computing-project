﻿import os
import time
import requests

# Retrieve the Node ID and API server URL from environment variables.
NODE_ID = os.environ.get("NODE_ID")
API_SERVER_URL = os.environ.get("API_SERVER_URL", "http://host.docker.internal:5000")

if not NODE_ID:
    print("NODE_ID environment variable not set. Exiting.")
    exit(1)

heartbeat_url = f"{API_SERVER_URL}/heartbeat"

print(f"Node container started for node {NODE_ID}. Sending heartbeats to {heartbeat_url}...")

while True:
    try:
        response = requests.post(heartbeat_url, json={"node_id": NODE_ID})
        print(f"Heartbeat sent for node {NODE_ID}: {response.status_code}")
    except Exception as e:
        print(f"Error sending heartbeat: {e}")
    time.sleep(3)  # Send a heartbeat every 3 seconds.

